/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package proyecto1;

import interfaz.Ventana;

/**
 * Rama principal
 * @author Miguel Montilla
 */
public class Proyecto1 {

    /**
     * @param args the command line arguments
     */
    
 /**
  * Visualización de la primera ventana
  * @param args the command line arguments
  */
    public static void main(String[] args) {
        // TODO code application logic here
        Ventana ventana = new Ventana();
        ventana.setVisible(true);
    }
    
}
