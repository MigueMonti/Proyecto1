/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package proyecto1;

/**
 * NodoUsuario representa la creación de los atributos almacenados en ListaUsuario
 * @author Miguel Montilla
 */
public class NodoUsuario {
    private NodoUsuario pnext;
    private int id;
    private String usuario;

/**
 * Nombramiento de las variables
 * @param id es el número asignado para identificar el usuario
 * @param usuario caracteres con el cual se identifica el usuario
 */
    public NodoUsuario(int id, String usuario) {
        this.pnext = null;
        this.id = id;
        this.usuario = usuario;
    }

    /**
     * @return the pnext
     */
    public NodoUsuario getPnext() {
        return pnext;
    }

    /**
     * @param pnext the pnext to set
     */
    public void setPnext(NodoUsuario pnext) {
        this.pnext = pnext;
    }

    /**
     * @return the id
     */
    public int getId() {
        return id;
    }

    /**
     * @param id the id to set
     */
    public void setId(int id) {
        this.id = id;
    }

    /**
     * @return the usuario
     */
    public String getUsuario() {
        return usuario;
    }

    /**
     * @param usuario the usuario to set
     */
    public void setUsuario(String usuario) {
        this.usuario = usuario;
    }
    
}
