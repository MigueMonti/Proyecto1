/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package proyecto1;

/**
 * NodoRelacion representa la creación de los atributos almacenados en ListaRelacion
 * @author Miguel Montilla
 */
public class NodoRelacion {
    private NodoRelacion pnext;
    private int usuario1;
    private int usuario2;
    private int amistad;

/**
 * Nombramiento de las variables
 * @param usuario1 número de id correspondiente a un usuario
 * @param usuario2 número de id correspondiente a un usuario
 * @param amistad número de años en relación los dos usuarios
 */
    public NodoRelacion(int usuario1, int usuario2, int amistad) {
        this.pnext = null;
        this.usuario1 = usuario1;
        this.usuario2 = usuario2;
        this.amistad = amistad;
    }

    /**
     * @return the pnext
     */
    public NodoRelacion getPnext() {
        return pnext;
    }

    /**
     * @param pnext the pnext to set
     */
    public void setPnext(NodoRelacion pnext) {
        this.pnext = pnext;
    }

    /**
     * @return the usuario1
     */
    public int getUsuario1() {
        return usuario1;
    }

    /**
     * @param usuario1 the usuario1 to set
     */
    public void setUsuario1(int usuario1) {
        this.usuario1 = usuario1;
    }

    /**
     * @return the usuario2
     */
    public int getUsuario2() {
        return usuario2;
    }

    /**
     * @param usuario2 the usuario2 to set
     */
    public void setUsuario2(int usuario2) {
        this.usuario2 = usuario2;
    }

    /**
     * @return the amistad
     */
    public int getAmistad() {
        return amistad;
    }

    /**
     * @param amistad the amistad to set
     */
    public void setAmistad(int amistad) {
        this.amistad = amistad;
    }

    
}
