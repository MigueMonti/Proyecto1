/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package proyecto1;

/**
 * ListaUsuario representa la lectura tipo lista del id y el usuario de la persona
 * @author Miguel Montilla
 */

public class ListaUsuario {
    private NodoUsuario inicio;
    private NodoUsuario fin;
    private int size;

/**
 * Atributos inciales de la clase
 */
    public ListaUsuario() {
        inicio = null;
        fin = null;
        size = 0;
    }

/**
 * Método para eliminar todos los elementos de la lista
 */
    public void vaciar(){
        setInicio(null);
        setFin(null);
        setSize(0);
    }

/**
 * Muestra si es Verdadero o Falso que la lista está vacía
 * @return devuelve la nulidad del atributo inicio
 */
    public boolean esta_vacia(){
        return getInicio() == null;
    }

/**
 * Método para agregar al inicio de la lista los datos del usuario
 * @param id es el número asignado para identificar el usuario
 * @param usuario caracteres con el cual se identifica el usuario
 */
    public void agregar_al_inicio(int id, String usuario){
        NodoUsuario nuevo = new NodoUsuario(id, usuario);
        if (esta_vacia()){
            setInicio(nuevo);
            setFin(nuevo);
        }else{
            nuevo.setPnext(getInicio());
            setInicio(nuevo);
        }
        setSize(getSize()+1);
    }
/**
 *  * Método para agregar al final de la lista los datos del usuario
 * @param id es el número asignado para identificar el usuario
 * @param usuario caracteres con el cual se identifica el usuario
 */
    public void agregar_al_final(int id, String usuario){
        NodoUsuario nuevo = new NodoUsuario(id, usuario);
        if (esta_vacia()){
            agregar_al_inicio(id, usuario);
        }else{
            getFin().setPnext(nuevo);
            setFin(nuevo);
            setSize(getSize()+1);
        }
    }
    
    /**
     * @return the inicio
     */
    public NodoUsuario getInicio() {
        return inicio;
    }

    /**
     * @param inicio the inicio to set
     */
    public void setInicio(NodoUsuario inicio) {
        this.inicio = inicio;
    }

    /**
     * @return the fin
     */
    public NodoUsuario getFin() {
        return fin;
    }

    /**
     * @param fin the fin to set
     */
    public void setFin(NodoUsuario fin) {
        this.fin = fin;
    }

    /**
     * @return the size
     */
    public int getSize() {
        return size;
    }

    /**
     * @param size the size to set
     */
    public void setSize(int size) {
        this.size = size;
    }
    
}
