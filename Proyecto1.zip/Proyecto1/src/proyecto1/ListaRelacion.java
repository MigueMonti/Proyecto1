/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package proyecto1;

/**
 * ListaRelacion representa la lectura tipo lista de las relaciones entre usuarios y los años de amistad entre ambos
 * @author Miguel Montilla
 */
public class ListaRelacion {
    private NodoRelacion inicio;
    private NodoRelacion fin;
    private int size;

/**
 * Atributos inciales de la clase
 */
    public ListaRelacion() {
        inicio = null;
        fin = null;
        size = 0;
    }

/**
 * Método para eliminar todos los elementos de la lista
 */
    public void vaciar(){
        setInicio(null);
        setFin(null);
        setSize(0);
    }

/**
 * Muestra si es Verdadero o Falso que la lista está vacía
 * @return devuelve la nulidad del atributo inicio
 */
    public boolean esta_vacia(){
        return getInicio() == null;
    }

/**
 * Método para agregar al inicio de la lista las relaciones entre los usuarios
 * @param usuario1 número de id correspondiente a un usuario
 * @param usuario2 número de id correspondiente a un usuario
 * @param amistad número de años en relación los dos usuarios
 */
    public void agregar_al_inicio(int usuario1, int usuario2, int amistad){
        NodoRelacion nuevo = new NodoRelacion(usuario1, usuario2, amistad);
        if (esta_vacia()){
            setInicio(nuevo);
            setFin(nuevo);
        }else{
            nuevo.setPnext(getInicio());
            setInicio(nuevo);
        }
        setSize(getSize()+1);
    }

/**
 * Método para agregar al inicio de la lista las relaciones entre los usuarios
 * @param usuario1 número de id correspondiente a un usuario
 * @param usuario2 número de id correspondiente a un usuario
 * @param amistad número de años en relación los dos usuarios
 */
    public void agregar_al_final(int usuario1, int usuario2, int amistad){
        NodoRelacion nuevo = new NodoRelacion(usuario1, usuario2, amistad);
        if (esta_vacia()){
            agregar_al_inicio(usuario1, usuario2, amistad);
        }else{
            getFin().setPnext(nuevo);
            setFin(nuevo);
            setSize(getSize()+1);
        }
    }
    
    /**
     * @return the inicio
     */
    public NodoRelacion getInicio() {
        return inicio;
    }

    /**
     * @param inicio the inicio to set
     */
    public void setInicio(NodoRelacion inicio) {
        this.inicio = inicio;
    }

    /**
     * @return the fin
     */
    public NodoRelacion getFin() {
        return fin;
    }

    /**
     * @param fin the fin to set
     */
    public void setFin(NodoRelacion fin) {
        this.fin = fin;
    }

    /**
     * @return the size
     */
    public int getSize() {
        return size;
    }

    /**
     * @param size the size to set
     */
    public void setSize(int size) {
        this.size = size;
    }

}
